export const Error = () => {
    return (
        <div style={{ textAlign: "center", margin: "40px", fontSize: "20px" }}>
            ارور داری بچه جان
        </div>
    )
}