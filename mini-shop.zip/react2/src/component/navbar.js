import { Link } from "react-router-dom"
import React from "react"
import { useSelector } from "react-redux"

export const Navbar = () => {
    const { isLogined, isErrored } = useSelector((state) => state.user)
    return (
        <nav style={{ padding: "20px", display: "flex", justifyContent: "center", border: "2px solid black", gap: "50px", backgroundColor: "red" }}>
            <Link style={{ textDecoration: "none", color: "black", backgroundColor: "white", padding: "10px", border: "2px solid black", borderRadius: "6px" }} to="/">Home</Link>
            {isLogined
                ? (<Link style={{ textDecoration: "none", color: "black", backgroundColor: "white", padding: "10px", border: "2px solid black", borderRadius: "6px" }} to="/profile">Profile</Link>)
                : (<><Link style={{ textDecoration: "none", color: "black", backgroundColor: "white", padding: "10px", border: "2px solid black", borderRadius: "6px" }} to="/login">Login</Link>
                    <Link style={{ textDecoration: "none", color: "black", backgroundColor: "white", padding: "10px", border: "2px solid black", borderRadius: "6px" }} to="/createAccont">Create Accont</Link>
                </>
                )}

        </nav>
    )
}