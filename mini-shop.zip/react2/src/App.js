import { Route, BrowserRouter, Routes } from "react-router-dom";
import { Navbar } from "./component/navbar";
import { Home } from "./Home";
import { CreateAccont } from "./pages/createAccont"
import { Login } from "./pages/login"
import { Profile } from "./pages/profile";
import { store } from "./store"
import { Error } from "./component/error";
import { Provider } from "react-redux";
function App() {

  return (
    <div className="App">
      <Provider store={store}>
        <BrowserRouter>
          <Navbar />
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/login" element={<Login />} />
            <Route path="/createAccont" element={<CreateAccont />} />
            <Route path="/profile" element={<Profile />} />
            <Route path="*" element={<Error />} />
          </Routes>
        </BrowserRouter>
      </Provider>
    </div>
  )
}


export default App;

