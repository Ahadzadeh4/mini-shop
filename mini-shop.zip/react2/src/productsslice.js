import { createSlice } from "@reduxjs/toolkit";
export const productsSlice = createSlice({
  name: "products",
  initialState: {
    list: [],          // ✅ همه محصولات اینجاست
    isComplited: false // برای نشون دادن تغییر
  },
  reducers: {
    createproduct: (state, action) => {
      state.list.push({
        id: Date.now(), // یه id منحصر به فرد
        name: action.payload.name,
        price: action.payload.price,
      });
      state.isComplited = true;
    },
   
  },
});

export const { createproduct } = productsSlice.actions;
export default productsSlice.reducer;