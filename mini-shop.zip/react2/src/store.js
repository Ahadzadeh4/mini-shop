import { configureStore } from "@reduxjs/toolkit";
import userReducer from "./userslice";
import productsReducer from "./productsslice";



export const store = configureStore({
  reducer: {
    user: userReducer,
    products: productsReducer,
  },
});



