import { useState, useEffect } from "react"
import { useDispatch } from "react-redux"
import { createaccont } from "../userslice"
import { useSelector } from "react-redux"

export const CreateAccont = () => {
    const [Name, setName] = useState("")
    const [Password, setPassword] = useState("")
    const [usernameerror, setusernameError] = useState("")
    const [passworderror, setpasswordError] = useState("")
    const [showMessageSucces, setShowMessageSucces] = useState(false)
    const [showMessageError, setShowMessageError] = useState(false)
    const { isLogined, isErrored } = useSelector((state) => state.user)
    const dispatch = useDispatch()
    useEffect(() => {
        if (isErrored) {
            setShowMessageError(true);
            const timer = setTimeout(() => {
                setShowMessageError(false);
            }, 2000);
            return () => clearTimeout(timer);
        }
    }, [isErrored]);
    useEffect(() => {
        if (isLogined) {
            setShowMessageSucces(true);
            const timer = setTimeout(() => {
                setShowMessageSucces(false);
            }, 2000);
            return () => clearTimeout(timer);
        }
    }, [isLogined]);
    const handleCreateAccount = () => {
        const passwordRegex = /^(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&]).{8,}$/;
        if (Name.trim() == "") {
            setusernameError("لطفا فیلد ها را کاملا پر کنید")
        } else if (Password.trim() == "") {
            setpasswordError("لطفا فیلد ها را کاملا پر کنید")
        } else if (Name.length < 6) {
            setusernameError("حداقل میزان کاراکتر 6 حرف است")
        } else if (Password.length < 8) {
            setpasswordError("حداقل میزان کاراکتر 8 حرف است")
        } else if (!passwordRegex.test(Password)) {
            setpasswordError("رمز باید حداقل ۸ کاراکتر، شامل حروف بزرگ و کوچک ، عدد و علامت خاص باشد 🔒")
        } else {
            dispatch(createaccont({
                username: Name,
                password: Password,
            }))
            setName("")
            setPassword("")
            setusernameError("")
            setpasswordError("")
        }
    }
    return (
        <div style={{ margin: "25px", padding: "10px", border: "2px solid black", borderRadius: "5px" }}>
            <h1>CreateAccont</h1>
            <p>
                <label htmlFor="username">Username : </label>
                <input value={Name} onChange={(event) => setName(event.target.value)} type="text" id="username" style={{ fontSize: "12px", padding: "5px", border: "2px solid black", borderRadius: "5px" }} />
                {usernameerror && <p style={{ color: "red", margin: "7px", fontFamily: "fantasy" }}>{usernameerror}</p>}
            </p>
            <p>
                <label htmlFor="password">Password : </label>
                <input value={Password} onChange={(event) => setPassword(event.target.value)} type="password" id="password" style={{ fontSize: "12px", padding: "5px", border: "2px solid black", borderRadius: "5px" }} />
                {passworderror && <p style={{ color: "red", margin: "7px", fontFamily: "fantasy" }}>{passworderror}</p>}
            </p>
            {showMessageSucces && (
                <p style={{ color: "green", fontFamily: "sans-serif" }}>
                    ورود موفق بود ✅
                </p>
            )}
            {showMessageError && <p style={{ color: "red" }}>نام کاربری و رمز وجود ندارد ❌</p>}
            <button onClick={handleCreateAccount} style={{ padding: "10px" }}>OK</button>
        </div>
    )
}