import { useSelector } from "react-redux"
import { useDispatch } from "react-redux"
import { useState } from "react"
import { logout } from "../userslice"
import { useNavigate } from "react-router-dom"
export const Profile = () => {
    const selectore = useSelector((state) => state.user)
    const selectore2 = useSelector((state) => state.products.list)
    const navigate = useNavigate()
    const dispatch = useDispatch()
    const [showLogoutConfirm, setShowLogoutConfirm] = useState(false)

    return (
        <div>
            {selectore.isLogined ? (<>
                <h1 style={{ textAlign: "center", margin: "3e0px" }}>Hi {selectore.username}</h1>
                <button style={{ padding: "7px", textAlign: "center", marginLeft: "47.5%" }} onClick={() => setShowLogoutConfirm(true)}>Logout</button>
                {showLogoutConfirm && (
                    <div style={{ margin: "50px", textAlign: "center", padding: "5px", border: "2px solid black", borderRadius: "5px" }}>
                        <p style={{ padding: "5px" }}>آیا می خوای خارج شوی ؟</p>
                        <button style={{ padding: "5px" }} onClick={() => {
                            dispatch(logout());
                            setShowLogoutConfirm(false);
                            navigate("/")
                        }}>بله </button>
                        <button style={{ padding: "5px" }} onClick={() => setShowLogoutConfirm(false)}>خیر</button>
                    </div>)}
                <div>
                    <h2>your products</h2>
                    {selectore2.map((item, index) => {
                        return (
                            <div
                                style={{
                                    display: "inline-block",
                                    margin: "30px",
                                    border: "2px solid black",
                                    padding: "10px",
                                    textAlign: "center",
                                    borderRadius: "5px",
                                }}
                                key={index}
                            >
                                <h1>{item.name}</h1>
                                <h2>{item.price}</h2>
                                <button>Buy now</button>
                            </div>
                        )

                    })}
                </div>
            </>) : (
                <h1 style={{ textAlign: "center", marginTop: "60px" }}>خطا</h1>
            )}

        </div>
    )
}