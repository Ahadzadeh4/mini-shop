import { useForm } from "react-hook-form"
import { useEffect, useState } from "react"
import { useDispatch } from "react-redux"
import { login } from "../userslice"
import { yupResolver } from "@hookform/resolvers/yup"
import { useSelector } from "react-redux"
import * as yup from "yup"

const schema = yup.object().shape({
    Username: yup.string().required("لطفا فیلد ها را کاملا پر کنید")
        .min(6, "حداقل میزان کاراکتر 6 حرف است"),
    Password: yup.string().required("لطفا فیلد ها را کاملا پر کنید")
        .min(8, "حداقل میزان کاراکتر 8 حرف است")
        .matches(
            /^(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&]).{8,}$/,
            "رمز باید حداقل ۸ کاراکتر، شامل حروف بزرگ و کوچک ، عدد و علامت خاص باشد 🔒"
        )
})
export const Login = () => {
    const { isLogined, isErrored } = useSelector((state) => state.user)
    const [showMessageSucces, setShowMessageSucces] = useState(false)
    const [showMessageError, setShowMessageError] = useState(false)
    useEffect(() => {
        if (isErrored) {
            setShowMessageError(true);
            const timer = setTimeout(() => {
                setShowMessageError(false);
            }, 2000);
            return () => clearTimeout(timer);
        }
    }, [isErrored]);
    useEffect(() => {
        if (isLogined) {
            setShowMessageSucces(true);
            const timer = setTimeout(() => {
                setShowMessageSucces(false);
            }, 2000);
            return () => clearTimeout(timer);
        }
    }, [isLogined]);
    const { register, handleSubmit, reset, formState: { errors } } = useForm({
        resolver: yupResolver(schema)
    })
    const dispatch = useDispatch()
    const OnsubmitForm = (data) => {
        dispatch(login({
            username: data.Username,
            password: data.Password,
        }))
        reset()
    }
    return (
        <div style={{ margin: "25px", padding: "10px", border: "2px solid black", borderRadius: "5px" }}>
            <h1>Login</h1>
            <form onSubmit={handleSubmit(OnsubmitForm)}>
                <p>
                    <label htmlFor="username">Username : </label>
                    <input type="text" id="username" {...register("Username")} style={{ fontSize: "12px", padding: "5px", border: "2px solid black", borderRadius: "5px" }} />
                    {errors.Username && <p style={{ color: "red", margin: "7px", fontFamily: "fantasy" }}>{errors.Username.message}</p>}
                </p>
                <p>
                    <label htmlFor="password">Password : </label>
                    <input type="password" id="password" {...register("Password")} style={{ fontSize: "12px", padding: "5px", border: "2px solid black", borderRadius: "5px" }} />
                    {errors.Password && <p style={{ color: "red", margin: "7px", fontFamily: "fantasy" }}>{errors.Password.message}</p>}
                </p>
                {showMessageSucces && (
                    <p style={{ color: "green", fontFamily: "sans-serif" }}>
                        ورود موفق بود ✅
                    </p>
                )}
                {showMessageError && <p style={{ color: "red" }}>نام کاربری و رمز وجود ندارد ❌</p>}
                <input type="submit" />
            </form>

        </div>
    )
}