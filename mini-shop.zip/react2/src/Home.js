import axios from "axios"
import React from "react"
import { useEffect, useState } from "react"
import { useSelector } from "react-redux"
import { useDispatch } from "react-redux"
import { createproduct } from "./productsslice"
export const Home = () => {
    const dispatch = useDispatch()
    const [Error, SetError] = useState(null)
    const [Data, SetData] = useState([])
    const [Name, setName] = useState("")
    const [Price, setPrice] = useState("")
    const [showelement, setShowElement] = useState(false)
    const selectore = useSelector((state) => state.user)
    const selectore2 = useSelector((state) => state.products.list)
    useEffect(() => {
        axios.get("https://mocki.io/v1/1cd4b741-4c04-4866-8add-c3a4e6079238").then((res) => {
            SetData(res.data)
        })
            .catch((error) => {
                SetError(error.message)
            })
    }, [])
    return (
        <React.Fragment>
            {Error ? (
                <h2>{Error}</h2>
            ) : (
                <>
                    <h1>{selectore.isLogined && selectore.username}</h1>

                    <div>
                        {Data.map((item, index) => (
                            <div
                                key={index}
                                style={{
                                    display: "inline-block",
                                    margin: "30px",
                                    border: "2px solid black",
                                    padding: "10px",
                                    textAlign: "center",
                                    borderRadius: "5px",
                                }}
                            >
                                <h1>{item.name}</h1>
                                <h2>{item.price}</h2>
                                <button>Buy now</button>
                            </div>
                        ))}

                        {selectore2.map((item, index) => {
                            return (
                                <div
                                    style={{
                                        display: "inline-block",
                                        margin: "30px",
                                        border: "2px solid black",
                                        padding: "10px",
                                        textAlign: "center",
                                        borderRadius: "5px",
                                    }}
                                    key={index}
                                >
                                    <h1>{item.name}</h1>
                                    <h2>{item.price}</h2>
                                    <button>Buy now</button>
                                </div>
                            )

                        })}



                    </div>
                    {selectore.isLogined && (
                        <div>
                            <button onClick={() => setShowElement(true)}>create product</button>

                            {showelement && (
                                <div>
                                    <input
                                        placeholder="name"
                                        type="text"
                                        onChange={(event) => setName(event.target.value)}
                                    />
                                    <input
                                        placeholder="price"
                                        type="number"
                                        onChange={(event) => setPrice(event.target.value)}
                                    />
                                    <button
                                        onClick={() => {
                                            dispatch(
                                                createproduct({
                                                    name: Name,
                                                    price: Price,
                                                    isComplited: true,
                                                })
                                            );
                                            setShowElement(false);
                                        }}
                                    >
                                        ok
                                    </button>
                                </div>
                            )}
                        </div>
                    )}

                </>
            )}
        </React.Fragment>

    )
}


