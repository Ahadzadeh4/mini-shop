import { createSlice } from "@reduxjs/toolkit";

export const userSlice = createSlice({
    name: "user",
    initialState: {
        username: "",
        password: "",
        isErrored: false,
        isLogined: false
    },
    reducers: {
        createaccont: (state, action) => {
            state.username = action.payload.username
            state.password = action.payload.password
            state.isLogined = true
            state.isErrored = false
        },
        login: (state, action) => {
            if (
                action.payload.username === state.username &&
                action.payload.password === state.password
            ) {
                state.isLogined = true
                state.isErrored = false
            } else {
                state.isLogined = false
                state.isErrored = true
            }
        },
        logout: (state) => {
            state.username = ""
            state.password = ""
            state.isLogined = false
            state.isErrored = false
        }
    }
})

export const { createaccont, login, logout } = userSlice.actions;
export default userSlice.reducer;